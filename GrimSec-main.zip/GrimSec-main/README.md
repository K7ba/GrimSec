## Installation Tutorial:

## First Step, Install GrimSec
git clone https://github.com/cvqi/GrimSec.git

## Next, Install Python3
sudo apt install python3

## After that, install discord.py
sudo apt install discord.py
